// src/lib/storage.ts
var API_BASE_URL = {
  production: "https://bookmark-lite.contextlab.top",
  development: "http://localhost:3000"
};
var NODE_ENV = "development";
var API_BASE_URL_VALUE = (API_BASE_URL[NODE_ENV] ?? API_BASE_URL.development).replace(/\/+$/, "");
var DEFAULT_SYNC_ENABLED = true;
var MAX_RETRY_COUNT = 3;
var STORAGE_KEYS = {
  token: "token",
  syncEnabled: "syncEnabled",
  failedQueue: "failedQueue"
};
async function getStorage(key) {
  const result = await chrome.storage.local.get(key);
  return result[key];
}
async function setStorage(key, value) {
  await chrome.storage.local.set({ [key]: value });
}
var storage = {
  STORAGE_KEYS,
  MAX_RETRY_COUNT,
  /**
   * 获取平台基址
   *
   * @returns 平台基址
   */
  async getApiBaseUrl() {
    return API_BASE_URL_VALUE;
  },
  /**
   * 获取 API Token
   *
   * @returns Token 明文，未配置则空串
   */
  async getToken() {
    return await getStorage(STORAGE_KEYS.token) ?? "";
  },
  /**
   * 设置 API Token
   *
   * @param token - Token 明文
   */
  async setToken(token) {
    await setStorage(STORAGE_KEYS.token, token);
  },
  /**
   * 获取同步开关
   *
   * @description 缺省回退到默认开
   * @returns 是否启用被动同步
   */
  async getSyncEnabled() {
    return await getStorage(STORAGE_KEYS.syncEnabled) ?? DEFAULT_SYNC_ENABLED;
  },
  /**
   * 设置同步开关
   *
   * @param enabled - 是否启用
   */
  async setSyncEnabled(enabled) {
    await setStorage(STORAGE_KEYS.syncEnabled, enabled);
  },
  /**
   * 获取失败队列
   *
   * @returns 失败队列项数组
   */
  async getFailedQueue() {
    return await getStorage(STORAGE_KEYS.failedQueue) ?? [];
  },
  /**
   * 设置失败队列
   *
   * @param queue - 失败队列项数组
   */
  async setFailedQueue(queue2) {
    await setStorage(STORAGE_KEYS.failedQueue, queue2);
  }
};

// src/lib/api.ts
var AuthError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "AuthError";
  }
};
async function pushBookmark(payload) {
  const apiBaseUrl = await storage.getApiBaseUrl();
  const token = await storage.getToken();
  if (!token) {
    throw new AuthError("\u672A\u914D\u7F6E API Token");
  }
  const response = await fetch(`${apiBaseUrl}/api/extension/bookmarks`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(payload)
  });
  if (response.status === 401) {
    throw new AuthError("Token \u65E0\u6548\u6216\u5DF2\u64A4\u9500");
  }
  if (!response.ok) {
    throw new Error(`\u670D\u52A1\u7AEF\u9519\u8BEF\uFF1A${response.status}`);
  }
  const json = await response.json();
  if (!json.ok) {
    throw new Error(json.error?.message ?? "\u672A\u77E5\u9519\u8BEF");
  }
  return { alreadyExists: json.data?.alreadyExists === true };
}
async function verifyToken(token) {
  const trimmed = token.trim();
  if (!trimmed) {
    throw new AuthError("\u8BF7\u586B\u5199 API Token");
  }
  const apiBaseUrl = await storage.getApiBaseUrl();
  const response = await fetch(`${apiBaseUrl}/api/extension/verify`, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${trimmed}`
    }
  });
  if (response.status === 401) {
    throw new AuthError("Token \u65E0\u6548\u6216\u5DF2\u64A4\u9500");
  }
  if (!response.ok) {
    throw new Error(`\u670D\u52A1\u7AEF\u9519\u8BEF\uFF1A${response.status}`);
  }
  return true;
}

// src/lib/queue.ts
async function enqueue(payload) {
  const queue2 = await storage.getFailedQueue();
  const item = {
    payload,
    retryCount: 0,
    addedAt: Date.now()
  };
  queue2.push(item);
  await storage.setFailedQueue(queue2);
  await updateBadge();
}
async function updateBadge() {
  const queue2 = await storage.getFailedQueue();
  const text = queue2.length > 0 ? String(queue2.length) : "";
  await chrome.action.setBadgeText({ text });
  await chrome.action.setBadgeBackgroundColor({ color: "#dc2626" });
}
async function attemptPush(payload) {
  try {
    return await pushBookmark(payload);
  } catch (error) {
    if (error instanceof AuthError) {
      throw error;
    }
    await enqueue(payload);
    throw error;
  }
}
var queue = {
  /**
   * 推送书签，失败时自动入队
   *
   * @description 主动/被动收藏的统一入口；鉴权失败抛 AuthError
   * @param payload - 书签载荷
   * @returns 成功时返回 alreadyExists 标记
   */
  async push(payload) {
    return attemptPush(payload);
  },
  /**
   * 刷新失败队列
   *
   * @description 在 service worker 启动、书签事件、popup 打开时调用；
   * 对队列中每项尝试重试，成功则移除，失败则递增 retryCount，超限标记失败
   */
  async flush() {
    const queue2 = await storage.getFailedQueue();
    if (queue2.length === 0) return;
    const remaining = [];
    for (const item of queue2) {
      try {
        await pushBookmark(item.payload);
      } catch (error) {
        if (error instanceof AuthError) {
          remaining.push(item);
          continue;
        }
        const nextRetry = item.retryCount + 1;
        if (nextRetry >= storage.MAX_RETRY_COUNT) {
          continue;
        }
        remaining.push({ ...item, retryCount: nextRetry });
      }
    }
    await storage.setFailedQueue(remaining);
    await updateBadge();
  },
  /**
   * 重试单条失败队列项
   *
   * @description 配置页单条重试入口；成功则从队列移除，失败则按策略保留
   * @param payload - 需要重试的书签载荷
   * @returns 重试是否成功
   */
  async retryOne(payload) {
    const queue2 = await storage.getFailedQueue();
    const index = queue2.findIndex((item2) => item2.payload.url === payload.url);
    if (index === -1) return false;
    const item = queue2[index];
    try {
      await pushBookmark(item.payload);
      queue2.splice(index, 1);
      await storage.setFailedQueue(queue2);
      await updateBadge();
      return true;
    } catch (error) {
      if (error instanceof AuthError) {
        return false;
      }
      const nextRetry = item.retryCount + 1;
      if (nextRetry >= storage.MAX_RETRY_COUNT) {
        queue2.splice(index, 1);
      } else {
        queue2[index] = { ...item, retryCount: nextRetry };
      }
      await storage.setFailedQueue(queue2);
      await updateBadge();
      return false;
    }
  },
  /**
   * 清空失败队列
   *
   * @description 配置页清空入口；清空存储并清除角标
   */
  async clearAll() {
    await storage.setFailedQueue([]);
    await updateBadge();
  }
};

// src/popup.ts
var state = {
  token: "",
  syncEnabled: true,
  tokenValid: null,
  queueCount: 0,
  status: "idle",
  message: ""
};
var ICONS = {
  plus: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>`,
  loader: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>`,
  check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>`,
  info: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>`,
  alert: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4M12 17h.01"/></svg>`,
  refresh: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>`,
  settings: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`
};
async function init() {
  state.token = await storage.getToken();
  state.syncEnabled = await storage.getSyncEnabled();
  state.queueCount = (await storage.getFailedQueue()).length;
  render();
  await queue.flush();
  state.queueCount = (await storage.getFailedQueue()).length;
  render();
  if (state.token) {
    try {
      await verifyToken(state.token);
      state.tokenValid = true;
    } catch (error) {
      state.tokenValid = error instanceof AuthError ? false : null;
    }
    render();
  }
}
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab ?? null;
}
async function handleSaveCurrent() {
  if (!state.token) {
    setStatus("noToken", "\u8BF7\u5148\u5728\u8BBE\u7F6E\u4E2D\u914D\u7F6E API Token");
    return;
  }
  const tab = await getActiveTab();
  if (!tab || !tab.url) {
    setStatus("error", "\u65E0\u6CD5\u83B7\u53D6\u5F53\u524D\u9875\u4FE1\u606F");
    return;
  }
  state.status = "saving";
  state.message = "";
  render();
  const payload = {
    url: tab.url,
    title: tab.title || tab.url,
    favicon: tab.favIconUrl
  };
  try {
    const { alreadyExists } = await queue.push(payload);
    if (alreadyExists) {
      setStatus("exists", "\u8FD9\u9875\u5DF2\u7ECF\u6536\u8FC7\u4E86");
    } else {
      setStatus("success", "\u6536\u597D\u4E86");
    }
  } catch (error) {
    if (error instanceof AuthError) {
      state.tokenValid = false;
      setStatus("authError", "Token \u65E0\u6548\uFF0C\u8BF7\u68C0\u67E5");
    } else {
      setStatus("error", "\u7F51\u7EDC\u5F02\u5E38\uFF0C\u5C06\u7A0D\u540E\u91CD\u8BD5");
    }
  }
  state.queueCount = (await storage.getFailedQueue()).length;
  render();
}
async function handleToggleSync() {
  state.syncEnabled = !state.syncEnabled;
  await storage.setSyncEnabled(state.syncEnabled);
  render();
}
function openOptions(hash) {
  const url = hash ? chrome.runtime.getURL(`options.html${hash}`) : chrome.runtime.getURL("options.html");
  void chrome.tabs.create({ url });
}
function setStatus(status, message) {
  state.status = status;
  state.message = message;
  render();
}
function statusIcon(status) {
  switch (status) {
    case "success":
      return ICONS.check;
    case "exists":
      return ICONS.info;
    default:
      return ICONS.alert;
  }
}
function render() {
  const root = document.getElementById("root");
  if (!root) return;
  const isSaving = state.status === "saving";
  const hasToken = state.token.trim().length > 0;
  const connClass = !hasToken ? "" : state.tokenValid === false ? "invalid" : "on";
  const connLabel = !hasToken ? "\u672A\u914D\u7F6E" : state.tokenValid === false ? "Token \u65E0\u6548" : "\u5DF2\u8FDE\u63A5";
  const showStatus = !!state.message && state.status !== "idle" && state.status !== "saving";
  const statusCls = state.status;
  const statusMsg = state.message;
  const statusIco = showStatus ? statusIcon(state.status) : "";
  root.innerHTML = `
    <div class="wrap">
      <div class="header">
        <div class="logo"><img src="icons/logo-48.png" alt="Bookmark Lite" /></div>
        <h1>Bookmark Lite</h1>
        <span id="conn-badge" class="conn ${connClass}" title="\u70B9\u51FB\u6253\u5F00\u8BBE\u7F6E">
          <span class="dot"></span>${connLabel}
        </span>
      </div>

      <button id="save-current" class="save-btn" ${isSaving ? "disabled" : ""}>
        <span class="${isSaving ? "spin" : ""}">${isSaving ? ICONS.loader : ICONS.plus}</span>
        ${isSaving ? "\u6536\u85CF\u4E2D\u2026" : "\u6536\u85CF\u8FD9\u4E00\u9875"}
      </button>

      <div class="status ${showStatus ? statusCls : "empty"}">
        ${showStatus ? `<span>${statusIco}</span><span>${statusMsg}</span>` : ""}
      </div>

      <div class="field">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="t">\u81EA\u52A8\u540C\u6B65</span>
            <span class="d">\u6D4F\u89C8\u5668\u539F\u751F\u6536\u85CF\u81EA\u52A8\u6536\u8FDB\u4E66\u7B7E\u5E93</span>
          </div>
          <button id="sync-toggle" class="switch ${state.syncEnabled ? "on" : ""}">
            <span class="knob"></span>
          </button>
        </div>
        ${state.queueCount > 0 ? `<div id="queue-note" class="queue-note">${ICONS.refresh}<span>${state.queueCount} \u6761\u5F85\u91CD\u8BD5\uFF0C\u91CD\u65B0\u6253\u5F00\u65F6\u81EA\u52A8\u91CD\u8BD5</span></div>` : ""}
      </div>

      <div id="settings-entry" class="settings-entry">
        ${ICONS.settings}<span>\u8BBE\u7F6E</span>
      </div>
    </div>
  `;
  document.getElementById("save-current")?.addEventListener("click", handleSaveCurrent);
  document.getElementById("sync-toggle")?.addEventListener("click", handleToggleSync);
  document.getElementById("conn-badge")?.addEventListener("click", () => openOptions());
  document.getElementById("settings-entry")?.addEventListener("click", () => openOptions());
  document.getElementById("queue-note")?.addEventListener("click", () => openOptions("#queue"));
}
document.addEventListener("DOMContentLoaded", init);
