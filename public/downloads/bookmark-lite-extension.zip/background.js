// src/lib/storage.ts
var API_BASE_URL = {
  production: "https://bookmark-lite.contextlab.top",
  development: "http://localhost:3000"
};
var NODE_ENV = "production";
var API_BASE_URL_VALUE = (API_BASE_URL[NODE_ENV] ?? API_BASE_URL.development).replace(/\/+$/, "");
var DEFAULT_SYNC_ENABLED = true;
var MAX_RETRY_COUNT = 3;
var STORAGE_KEYS = {
  token: "token",
  syncEnabled: "syncEnabled",
  failedQueue: "failedQueue"
};
async function getStorage(key) {
  const result = await chrome.storage.local.get(key);
  return result[key];
}
async function setStorage(key, value) {
  await chrome.storage.local.set({ [key]: value });
}
var storage = {
  STORAGE_KEYS,
  MAX_RETRY_COUNT,
  /**
   * 获取平台基址
   *
   * @returns 平台基址
   */
  async getApiBaseUrl() {
    return API_BASE_URL_VALUE;
  },
  /**
   * 获取 API Token
   *
   * @returns Token 明文，未配置则空串
   */
  async getToken() {
    return await getStorage(STORAGE_KEYS.token) ?? "";
  },
  /**
   * 设置 API Token
   *
   * @param token - Token 明文
   */
  async setToken(token) {
    await setStorage(STORAGE_KEYS.token, token);
  },
  /**
   * 获取同步开关
   *
   * @description 缺省回退到默认开
   * @returns 是否启用被动同步
   */
  async getSyncEnabled() {
    return await getStorage(STORAGE_KEYS.syncEnabled) ?? DEFAULT_SYNC_ENABLED;
  },
  /**
   * 设置同步开关
   *
   * @param enabled - 是否启用
   */
  async setSyncEnabled(enabled) {
    await setStorage(STORAGE_KEYS.syncEnabled, enabled);
  },
  /**
   * 获取失败队列
   *
   * @returns 失败队列项数组
   */
  async getFailedQueue() {
    return await getStorage(STORAGE_KEYS.failedQueue) ?? [];
  },
  /**
   * 设置失败队列
   *
   * @param queue - 失败队列项数组
   */
  async setFailedQueue(queue2) {
    await setStorage(STORAGE_KEYS.failedQueue, queue2);
  }
};

// src/lib/api.ts
var AuthError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "AuthError";
  }
};
async function pushBookmark(payload) {
  const apiBaseUrl = await storage.getApiBaseUrl();
  const token = await storage.getToken();
  if (!token) {
    throw new AuthError("\u672A\u914D\u7F6E API Token");
  }
  const response = await fetch(`${apiBaseUrl}/api/extension/bookmarks`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(payload)
  });
  if (response.status === 401) {
    throw new AuthError("Token \u65E0\u6548\u6216\u5DF2\u64A4\u9500");
  }
  if (!response.ok) {
    throw new Error(`\u670D\u52A1\u7AEF\u9519\u8BEF\uFF1A${response.status}`);
  }
  const json = await response.json();
  if (!json.ok) {
    throw new Error(json.error?.message ?? "\u672A\u77E5\u9519\u8BEF");
  }
  return { alreadyExists: json.data?.alreadyExists === true };
}

// src/lib/queue.ts
async function enqueue(payload) {
  const queue2 = await storage.getFailedQueue();
  const item = {
    payload,
    retryCount: 0,
    addedAt: Date.now()
  };
  queue2.push(item);
  await storage.setFailedQueue(queue2);
  await updateBadge();
}
async function updateBadge() {
  const queue2 = await storage.getFailedQueue();
  const text = queue2.length > 0 ? String(queue2.length) : "";
  await chrome.action.setBadgeText({ text });
  await chrome.action.setBadgeBackgroundColor({ color: "#dc2626" });
}
async function attemptPush(payload) {
  try {
    return await pushBookmark(payload);
  } catch (error) {
    if (error instanceof AuthError) {
      throw error;
    }
    await enqueue(payload);
    throw error;
  }
}
var queue = {
  /**
   * 推送书签，失败时自动入队
   *
   * @description 主动/被动收藏的统一入口；鉴权失败抛 AuthError
   * @param payload - 书签载荷
   * @returns 成功时返回 alreadyExists 标记
   */
  async push(payload) {
    return attemptPush(payload);
  },
  /**
   * 刷新失败队列
   *
   * @description 在 service worker 启动、书签事件、popup 打开时调用；
   * 对队列中每项尝试重试，成功则移除，失败则递增 retryCount，超限标记失败
   */
  async flush() {
    const queue2 = await storage.getFailedQueue();
    if (queue2.length === 0) return;
    const remaining = [];
    for (const item of queue2) {
      try {
        await pushBookmark(item.payload);
      } catch (error) {
        if (error instanceof AuthError) {
          remaining.push(item);
          continue;
        }
        const nextRetry = item.retryCount + 1;
        if (nextRetry >= storage.MAX_RETRY_COUNT) {
          continue;
        }
        remaining.push({ ...item, retryCount: nextRetry });
      }
    }
    await storage.setFailedQueue(remaining);
    await updateBadge();
  }
};

// src/background.ts
function buildPayloadFromNode(node) {
  if (!node.url) {
    return null;
  }
  return {
    url: node.url,
    title: node.title || node.url
  };
}
function initBookmarkListener() {
  chrome.bookmarks.onCreated.addListener(async (_id, node) => {
    const syncEnabled = await storage.getSyncEnabled();
    if (!syncEnabled) return;
    const payload = buildPayloadFromNode(node);
    if (!payload) return;
    try {
      await queue.push(payload);
    } catch (error) {
      if (error instanceof AuthError) {
        return;
      }
    }
  });
}
function init() {
  initBookmarkListener();
  void queue.flush();
}
init();
