// src/lib/storage.ts
var API_BASE_URL = {
  production: "https://bookmark-lite.contextlab.top",
  development: "http://localhost:3000"
};
var NODE_ENV = "production";
var API_BASE_URL_VALUE = (API_BASE_URL[NODE_ENV] ?? API_BASE_URL.development).replace(/\/+$/, "");
var DEFAULT_SYNC_ENABLED = true;
var MAX_RETRY_COUNT = 3;
var STORAGE_KEYS = {
  token: "token",
  syncEnabled: "syncEnabled",
  failedQueue: "failedQueue"
};
async function getStorage(key) {
  const result = await chrome.storage.local.get(key);
  return result[key];
}
async function setStorage(key, value) {
  await chrome.storage.local.set({ [key]: value });
}
var storage = {
  STORAGE_KEYS,
  MAX_RETRY_COUNT,
  /**
   * 获取平台基址
   *
   * @returns 平台基址
   */
  async getApiBaseUrl() {
    return API_BASE_URL_VALUE;
  },
  /**
   * 获取 API Token
   *
   * @returns Token 明文，未配置则空串
   */
  async getToken() {
    return await getStorage(STORAGE_KEYS.token) ?? "";
  },
  /**
   * 设置 API Token
   *
   * @param token - Token 明文
   */
  async setToken(token) {
    await setStorage(STORAGE_KEYS.token, token);
  },
  /**
   * 获取同步开关
   *
   * @description 缺省回退到默认开
   * @returns 是否启用被动同步
   */
  async getSyncEnabled() {
    return await getStorage(STORAGE_KEYS.syncEnabled) ?? DEFAULT_SYNC_ENABLED;
  },
  /**
   * 设置同步开关
   *
   * @param enabled - 是否启用
   */
  async setSyncEnabled(enabled) {
    await setStorage(STORAGE_KEYS.syncEnabled, enabled);
  },
  /**
   * 获取失败队列
   *
   * @returns 失败队列项数组
   */
  async getFailedQueue() {
    return await getStorage(STORAGE_KEYS.failedQueue) ?? [];
  },
  /**
   * 设置失败队列
   *
   * @param queue - 失败队列项数组
   */
  async setFailedQueue(queue2) {
    await setStorage(STORAGE_KEYS.failedQueue, queue2);
  }
};

// src/lib/api.ts
var AuthError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "AuthError";
  }
};
async function pushBookmark(payload) {
  const apiBaseUrl = await storage.getApiBaseUrl();
  const token = await storage.getToken();
  if (!token) {
    throw new AuthError("\u672A\u914D\u7F6E API Token");
  }
  const response = await fetch(`${apiBaseUrl}/api/extension/bookmarks`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(payload)
  });
  if (response.status === 401) {
    throw new AuthError("Token \u65E0\u6548\u6216\u5DF2\u64A4\u9500");
  }
  if (!response.ok) {
    throw new Error(`\u670D\u52A1\u7AEF\u9519\u8BEF\uFF1A${response.status}`);
  }
  const json = await response.json();
  if (!json.ok) {
    throw new Error(json.error?.message ?? "\u672A\u77E5\u9519\u8BEF");
  }
  return { alreadyExists: json.data?.alreadyExists === true };
}
async function verifyToken(token) {
  const trimmed = token.trim();
  if (!trimmed) {
    throw new AuthError("\u8BF7\u586B\u5199 API Token");
  }
  const apiBaseUrl = await storage.getApiBaseUrl();
  const response = await fetch(`${apiBaseUrl}/api/extension/verify`, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${trimmed}`
    }
  });
  if (response.status === 401) {
    throw new AuthError("Token \u65E0\u6548\u6216\u5DF2\u64A4\u9500");
  }
  if (!response.ok) {
    throw new Error(`\u670D\u52A1\u7AEF\u9519\u8BEF\uFF1A${response.status}`);
  }
  return true;
}

// src/lib/queue.ts
async function enqueue(payload) {
  const queue2 = await storage.getFailedQueue();
  const item = {
    payload,
    retryCount: 0,
    addedAt: Date.now()
  };
  queue2.push(item);
  await storage.setFailedQueue(queue2);
  await updateBadge();
}
async function updateBadge() {
  const queue2 = await storage.getFailedQueue();
  const text = queue2.length > 0 ? String(queue2.length) : "";
  await chrome.action.setBadgeText({ text });
  await chrome.action.setBadgeBackgroundColor({ color: "#dc2626" });
}
async function attemptPush(payload) {
  try {
    return await pushBookmark(payload);
  } catch (error) {
    if (error instanceof AuthError) {
      throw error;
    }
    await enqueue(payload);
    throw error;
  }
}
var queue = {
  /**
   * 推送书签，失败时自动入队
   *
   * @description 主动/被动收藏的统一入口；鉴权失败抛 AuthError
   * @param payload - 书签载荷
   * @returns 成功时返回 alreadyExists 标记
   */
  async push(payload) {
    return attemptPush(payload);
  },
  /**
   * 刷新失败队列
   *
   * @description 在 service worker 启动、书签事件、popup 打开时调用；
   * 对队列中每项尝试重试，成功则移除，失败则递增 retryCount，超限标记失败
   */
  async flush() {
    const queue2 = await storage.getFailedQueue();
    if (queue2.length === 0) return;
    const remaining = [];
    for (const item of queue2) {
      try {
        await pushBookmark(item.payload);
      } catch (error) {
        if (error instanceof AuthError) {
          remaining.push(item);
          continue;
        }
        const nextRetry = item.retryCount + 1;
        if (nextRetry >= storage.MAX_RETRY_COUNT) {
          continue;
        }
        remaining.push({ ...item, retryCount: nextRetry });
      }
    }
    await storage.setFailedQueue(remaining);
    await updateBadge();
  }
};

// src/popup.ts
var state = {
  token: "",
  syncEnabled: true,
  tokenVisible: false,
  verifyingToken: false,
  tokenValid: null,
  queueCount: 0,
  status: "idle",
  message: ""
};
var ICONS = {
  bookmark: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>`,
  plus: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>`,
  loader: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>`,
  check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>`,
  info: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>`,
  alert: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4M12 17h.01"/></svg>`,
  eye: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>`,
  eyeOff: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-10-7-10-7a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 10 7 10 7a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><path d="M1 1l22 22"/></svg>`,
  refresh: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>`
};
async function init() {
  state.token = await storage.getToken();
  state.syncEnabled = await storage.getSyncEnabled();
  state.queueCount = (await storage.getFailedQueue()).length;
  render();
  await queue.flush();
  state.queueCount = (await storage.getFailedQueue()).length;
  render();
  if (state.token) {
    try {
      await verifyToken(state.token);
      state.tokenValid = true;
    } catch (error) {
      state.tokenValid = error instanceof AuthError ? false : null;
    }
    render();
  }
}
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab ?? null;
}
async function handleSaveCurrent() {
  if (!state.token) {
    setStatus("noToken", "\u8BF7\u5148\u586B\u5199 API Token");
    return;
  }
  const tab = await getActiveTab();
  if (!tab || !tab.url) {
    setStatus("error", "\u65E0\u6CD5\u83B7\u53D6\u5F53\u524D\u9875\u4FE1\u606F");
    return;
  }
  state.status = "saving";
  state.message = "";
  render();
  const payload = {
    url: tab.url,
    title: tab.title || tab.url,
    favicon: tab.favIconUrl
  };
  try {
    const { alreadyExists } = await queue.push(payload);
    if (alreadyExists) {
      setStatus("exists", "\u5DF2\u5728\u4E66\u7B7E\u5E93\u4E2D");
    } else {
      setStatus("success", "\u5DF2\u6536\u85CF\u5230\u4E66\u7B7E\u5E93");
    }
  } catch (error) {
    if (error instanceof AuthError) {
      state.tokenValid = false;
      setStatus("authError", "Token \u65E0\u6548\uFF0C\u8BF7\u68C0\u67E5");
    } else {
      setStatus("error", "\u7F51\u7EDC\u5F02\u5E38\uFF0C\u5C06\u7A0D\u540E\u91CD\u8BD5");
    }
  }
  state.queueCount = (await storage.getFailedQueue()).length;
  render();
}
async function handleSaveToken() {
  const token = state.token.trim();
  if (!token) {
    setStatus("noToken", "\u8BF7\u5148\u586B\u5199 API Token");
    return;
  }
  await storage.setToken(token);
  state.token = token;
  state.verifyingToken = true;
  state.status = "success";
  state.message = "Token \u5DF2\u4FDD\u5B58\uFF0C\u6B63\u5728\u6821\u9A8C";
  render();
  try {
    await verifyToken(token);
    state.tokenValid = true;
    setStatusAfterVerify("success", "Token \u6709\u6548\uFF0C\u5DF2\u4FDD\u5B58");
  } catch (error) {
    state.tokenValid = error instanceof AuthError ? false : null;
    setStatusAfterVerify(
      error instanceof AuthError ? "authError" : "error",
      error instanceof AuthError ? "Token \u5DF2\u4FDD\u5B58\uFF0C\u4F46\u6821\u9A8C\u65E0\u6548" : "Token \u5DF2\u4FDD\u5B58\uFF0C\u6821\u9A8C\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC"
    );
  }
}
function setStatusAfterVerify(status, message) {
  state.verifyingToken = false;
  setStatus(status, message);
}
async function handleToggleSync() {
  state.syncEnabled = !state.syncEnabled;
  await storage.setSyncEnabled(state.syncEnabled);
  render();
}
function setStatus(status, message) {
  state.status = status;
  state.message = message;
  render();
}
function statusIcon(status) {
  switch (status) {
    case "success":
      return ICONS.check;
    case "exists":
      return ICONS.info;
    default:
      return ICONS.alert;
  }
}
function render() {
  const root = document.getElementById("root");
  if (!root) return;
  const isSaving = state.status === "saving";
  const verifying = state.verifyingToken;
  const hasToken = state.token.trim().length > 0;
  const connClass = !hasToken ? "" : state.tokenValid === false ? "invalid" : "on";
  const connLabel = !hasToken ? "\u672A\u914D\u7F6E" : state.tokenValid === false ? "Token \u65E0\u6548" : "\u5DF2\u8FDE\u63A5";
  const showStatus = verifying || !!state.message && state.status !== "idle" && state.status !== "saving";
  const statusCls = verifying ? "verifying" : state.status;
  const statusMsg = verifying ? "\u6821\u9A8C\u4E2D\u2026" : state.message;
  const statusIco = verifying ? ICONS.loader : showStatus ? statusIcon(state.status) : "";
  root.innerHTML = `
    <div class="wrap">
      <div class="header">
        <div class="logo">${ICONS.bookmark}</div>
        <h1>Bookmark Lite</h1>
        <span class="conn ${connClass}">
          <span class="dot"></span>${connLabel}
        </span>
      </div>

      <div class="field no-divider">
        <span class="label">API Token</span>
        <div class="token-row">
          <div class="input-wrap">
            <input id="token-input" type="${state.tokenVisible ? "text" : "password"}"
              value="${escapeHtml(state.token)}" placeholder="\u7C98\u8D34 Token \u660E\u6587" class="token-input" />
            <button id="toggle-eye" class="eye" title="\u663E\u793A/\u9690\u85CF">
              ${state.tokenVisible ? ICONS.eyeOff : ICONS.eye}
            </button>
          </div>
          <button id="save-token" class="btn-ghost" ${state.verifyingToken ? "disabled" : ""}>
            ${state.verifyingToken ? `<span class="spin">${ICONS.loader}</span>` : "\u4FDD\u5B58"}
          </button>
        </div>
      </div>

      <button id="save-current" class="save-btn" ${isSaving ? "disabled" : ""}>
        <span class="${isSaving ? "spin" : ""}">${isSaving ? ICONS.loader : ICONS.plus}</span>
        ${isSaving ? "\u6536\u85CF\u4E2D\u2026" : "\u6536\u85CF\u5F53\u524D\u9875"}
      </button>

      <div class="status ${showStatus ? statusCls : "empty"}">
        ${showStatus ? `<span class="${verifying ? "spin" : ""}">${statusIco}</span><span>${statusMsg}</span>` : ""}
      </div>

      <div class="field">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="t">\u88AB\u52A8\u540C\u6B65</span>
            <span class="d">\u6D4F\u89C8\u5668\u539F\u751F\u6536\u85CF\u65F6\u81EA\u52A8\u63A8\u9001</span>
          </div>
          <button id="sync-toggle" class="switch ${state.syncEnabled ? "on" : ""}">
            <span class="knob"></span>
          </button>
        </div>
        ${state.queueCount > 0 ? `<div class="queue-note">${ICONS.refresh}<span>${state.queueCount} \u6761\u5F85\u91CD\u8BD5\uFF0C\u91CD\u65B0\u6253\u5F00\u65F6\u81EA\u52A8\u91CD\u8BD5</span></div>` : ""}
      </div>
    </div>
  `;
  document.getElementById("save-current")?.addEventListener("click", handleSaveCurrent);
  document.getElementById("save-token")?.addEventListener("click", handleSaveToken);
  document.getElementById("toggle-eye")?.addEventListener("click", () => {
    state.tokenVisible = !state.tokenVisible;
    render();
  });
  document.getElementById("token-input")?.addEventListener("input", (e) => {
    state.token = e.target.value;
  });
  document.getElementById("sync-toggle")?.addEventListener("click", handleToggleSync);
}
function escapeHtml(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
document.addEventListener("DOMContentLoaded", init);
